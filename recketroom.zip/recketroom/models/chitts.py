from . import db
from datetime import datetime

class Chitt(db.Model):
    __tablename__ = 'chitts'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    participants_json = db.Column(db.Text)       # list of roommate IDs as JSON
    assigned_works_json = db.Column(db.Text)     # dict roommate_id -> [works]
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
