from . import db
from datetime import datetime

class Tiffin(db.Model):
    __tablename__ = 'tiffins'
    id = db.Column(db.Integer, primary_key=True)
    recipe = db.Column(db.String(200), nullable=False)
    image_path = db.Column(db.String(300), nullable=True)
    week_day = db.Column(db.String(20), nullable=True)  # Monday..Sunday
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
