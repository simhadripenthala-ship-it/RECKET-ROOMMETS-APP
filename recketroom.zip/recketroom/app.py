# app.py
import os, json, random
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.utils import secure_filename

# Models and helpers
from models import db
from models.user import User
from models.chitts import Chitt
from models.bills import Expense
from models.chores import Chore
from models.veggie import Veggie
from models.tiffin import Tiffin
from models.Roommate import Roommate  # ensure filename is models/roommate.py
from utils.helpers import create_user, get_current_user

# ------------------ APP CONFIG ------------------
app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = "your_secret_key"

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///recketroom.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Upload folders
app.config["UPLOAD_FOLDER_ROOMMATES"] = os.path.join(BASE_DIR, "static", "uploads", "roommates")
app.config["UPLOAD_FOLDER_TIFFINS"]  = os.path.join(BASE_DIR, "static", "uploads", "tiffins")
os.makedirs(app.config["UPLOAD_FOLDER_ROOMMATES"], exist_ok=True)
os.makedirs(app.config["UPLOAD_FOLDER_TIFFINS"],  exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# DB init
db.init_app(app)
with app.app_context():
    db.create_all()

# ------------------ ROUTES ------------------

@app.route("/ping")
def ping():
    return {"ok": True, "ts": datetime.utcnow().isoformat()}

# Home / Dashboard
@app.route("/")
def home():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("dashboard.html", username=user.username)

# ------------------ AUTH ------------------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        email    = request.form.get("email")
        contact_number = request.form.get("contact_number")
        user = create_user(username, email, password, contact_number)
        if not user:
            flash("Username or email already exists!", "danger")
            return redirect(url_for("signup"))
        flash("Account created successfully! Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session["user_id"] = user.id
            flash("Login successful!", "success")
            return redirect(url_for("home"))
        flash("Invalid credentials!", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user_id", None)
    flash("Logged out successfully!", "info")
    return redirect(url_for("login"))

# ------------------ ROOMMATES ------------------
@app.route("/roommates", methods=["GET", "POST"])
def roommates_view():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        name    = request.form.get("name")
        email   = request.form.get("email")
        contact = request.form.get("contact")
        image   = request.files.get("image")

        image_path = None
        if image and image.filename and allowed_file(image.filename):
            filename  = secure_filename(image.filename)
            save_path = os.path.join(app.config["UPLOAD_FOLDER_ROOMMATES"], filename)
            image.save(save_path)
            image_path = f"uploads/roommates/{filename}"  # served via url_for('static', filename=...)

        rm = Roommate(name=name, email=email, contact_number=contact, image_path=image_path)
        db.session.add(rm)
        db.session.commit()
        flash("Roommate added successfully!", "success")
        return redirect(url_for("roommates_view"))

    roommates = Roommate.query.order_by(Roommate.created_at.desc()).all()
    return render_template("roommates.html", roommates=roommates)

# ------------------ CHITTS ------------------
@app.route("/chitts", methods=["GET", "POST"])
def chitts_view():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    roommates = Roommate.query.all()
    chitts    = Chitt.query.order_by(Chitt.created_at.desc()).all()

    if request.method == "POST":
        title      = request.form.get("title")
        works_raw  = request.form.get("works", "")
        works_list = [w.strip() for w in works_raw.split(",") if w.strip()]

        if len(works_list) != len(roommates):
            flash(f"Number of works ({len(works_list)}) must equal number of roommates ({len(roommates)}).", "danger")
            return redirect(url_for("chitts_view"))

        participant_ids = [r.id for r in roommates]
        assigned_works  = {}

        if "random_assign" in request.form:
            shuffled = participant_ids[:]
            random.shuffle(shuffled)
            for idx, work in enumerate(works_list):
                pid = shuffled[idx]
                assigned_works.setdefault(pid, []).append(work)

        chitt = Chitt(
            title=title,
            participants_json=json.dumps(participant_ids),
            assigned_works_json=json.dumps(assigned_works),
        )
        db.session.add(chitt)
        db.session.commit()
        flash("Chitt saved! Random assignment performed if selected.", "success")
        return redirect(url_for("chitts_view"))

    roommate_map = {r.id: r.name for r in roommates}
    display = []
    for c in chitts:
        try:
            assigned = json.loads(c.assigned_works_json or "{}")
        except Exception:
            assigned = {}
        resolved = {roommate_map.get(int(pid), f"ID {pid}"): works for pid, works in assigned.items()}
        display.append({"title": c.title, "created_at": c.created_at, "assigned": resolved})

    return render_template("chitts.html", roommates=roommates, chitts=display)

# ------------------ EXPENSES ------------------
@app.route("/expenses", methods=["GET", "POST"])
def expenses_view():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    fixed_bills   = {"Room Rent": 0, "Gas Refill": 0, "Water Bill": 0, "Current Bill": 0}
    balance_money = 0
    total_exp     = 0
    custom_items  = []

    if request.method == "POST":
        total_exp = float(request.form.get("total_exp", 0) or 0)
        fixed_bills["Room Rent"]    = round(total_exp * 0.40, 2)
        fixed_bills["Gas Refill"]   = round(total_exp * 0.15, 2)
        fixed_bills["Water Bill"]   = round(total_exp * 0.15, 2)
        fixed_bills["Current Bill"] = round(total_exp * 0.20, 2)

        add_label  = request.form.get("add_label")
        add_amount = float(request.form.get("add_amount", 0) or 0)
        if add_label and add_amount > 0:
            custom_items.append({"label": add_label, "amount": add_amount})

        deductions    = sum(fixed_bills.values()) + sum(i["amount"] for i in custom_items)
        balance_money = round(total_exp - deductions, 2)

    return render_template(
        "expenses.html",
        total_exp=total_exp,
        fixed_bills=fixed_bills,
        custom_items=custom_items,
        balance_money=balance_money,
    )

# ------------------ TIFFINS ------------------
@app.route("/tiffin", methods=["GET", "POST"])
def tiffin_view():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        recipe   = request.form.get("recipe")
        week_day = request.form.get("week_day")
        image    = request.files.get("image")

        image_path = None
        if image and image.filename and allowed_file(image.filename):
            filename  = secure_filename(image.filename)
            save_path = os.path.join(app.config["UPLOAD_FOLDER_TIFFINS"], filename)
            image.save(save_path)
            image_path = f"uploads/tiffins/{filename}"

        tiffin = Tiffin(recipe=recipe, image_path=image_path, week_day=week_day)
        db.session.add(tiffin)
        db.session.commit()
        flash("Tiffin added!", "success")
        return redirect(url_for("tiffin_view"))

    search  = request.args.get("search", "").strip().lower()
    tiffins = Tiffin.query.order_by(Tiffin.created_at.desc()).all()
    if search:
        tiffins = [t for t in tiffins if search in (t.recipe or "").lower()]

    week   = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    weekly = {d: [] for d in week}
    for t in tiffins:
        if t.week_day in weekly:
            weekly[t.week_day].append(t)

    return render_template("tiffin.html", tiffins=tiffins, weekly=weekly)

# ------------------ VEGGIES ------------------
@app.route("/veggies", methods=["GET", "POST"])
def veggies_view():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        name         = request.form["name"]
        qty          = float(request.form.get("quantity", 0) or 0)
        cost         = float(request.form.get("cost", 0) or 0)
        curry_recipe = request.form.get("curry_recipe")

        v = Veggie(name=name, quantity_kg=qty, cost_per_kg=cost, curry_recipe=curry_recipe)
        db.session.add(v)
        db.session.commit()
        flash("Veggie added!", "success")
        return redirect(url_for("veggies_view"))

    veggies = Veggie.query.order_by(Veggie.created_at.desc()).all()
    return render_template("veggies.html", veggies=veggies)

# ------------------ RICE CALCULATOR ------------------
@app.route("/rice-calculator", methods=["GET", "POST"])
def rice_calculator():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))

    result = None
    if request.method == "POST":
        try:
            people     = int(request.form.get("people", 0))
            appetite   = request.form.get("appetite", "normal")
            per_person = 70 if appetite == "low" else 90 if appetite == "normal" else 120
            rice_grams = people * per_person
            water_ml   = rice_grams * 2
            result     = {"people": people, "per_person": per_person, "rice_grams": rice_grams, "water_ml": water_ml}
        except Exception:
            flash("Invalid input provided.", "danger")
    return render_template("rice_calculator.html", result=result)

# ------------------ RECIPES ------------------
@app.route("/recipes")
def recipes():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    items = [
        {"name":"Paneer Butter Masala","icon":"🧀","time":40,"serves":4,"difficulty":"Medium","desc":"Creamy tomato-onion gravy with paneer.","tags":["North Indian","Veg"]},
        {"name":"Chole Bhature","icon":"🍛","time":60,"serves":4,"difficulty":"Medium","desc":"Spiced chickpeas with fried bread.","tags":["Punjabi","Veg"]},
        {"name":"Dal Makhani","icon":"🥣","time":55,"serves":4,"difficulty":"Easy","desc":"Slow-cooked black lentils finished with butter.","tags":["North Indian","Veg"]},
        {"name":"Veg Biryani","icon":"🍚","time":50,"serves":4,"difficulty":"Medium","desc":"Layered fragrant rice with vegetables and spices.","tags":["Rice","Veg"]},
        {"name":"Aloo Gobi","icon":"🥦","time":30,"serves":3,"difficulty":"Easy","desc":"Dry curry of potatoes and cauliflower.","tags":["Everyday","Veg"]},
        {"name":"Masala Dosa","icon":"🥞","time":35,"serves":3,"difficulty":"Medium","desc":"Crisp dosa with spiced potato masala.","tags":["South Indian","Veg"]},
        {"name":"Idli Sambhar","icon":"🍲","time":40,"serves":4,"difficulty":"Easy","desc":"Steamed rice cakes with lentil-vegetable stew.","tags":["South Indian","Veg"]},
        {"name":"Pav Bhaji","icon":"🍞","time":35,"serves":4,"difficulty":"Easy","desc":"Spiced mashed vegetables with buttered buns.","tags":["Street Food","Veg"]},
        {"name":"Rajma Chawal","icon":"🍛","time":45,"serves":4,"difficulty":"Easy","desc":"Kidney bean curry with steamed rice.","tags":["North Indian","Veg"]},
        {"name":"Vegetable Pulao","icon":"🥕","time":25,"serves":3,"difficulty":"Easy","desc":"One-pot spiced rice with vegetables.","tags":["Rice","Veg"]},
    ]
    return render_template("recipes.html", items=items)

# ------------------ ROOM INFO ------------------
@app.route("/roominfo")
def roominfo():
    user = get_current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("roominfo.html")

# ------------------ RUN ------------------
if __name__ == "__main__":
    # Avoid double-start during development
    app.run(debug=True, use_reloader=False)
